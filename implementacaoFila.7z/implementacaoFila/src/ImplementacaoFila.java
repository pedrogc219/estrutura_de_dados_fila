import java.util.Scanner;

public class ImplementacaoFila {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int tamanho;

        System.out.println("Implementacao de fila");

        System.out.print("\nTamanho da fila: ");
        tamanho = scanner.nextInt();
        Fila fila = new Fila(tamanho);

        System.out.println("\nAcoes:");
        System.out.println("0 - Insere");
        System.out.println("1 - remover");
        System.out.println("2 - consultar");
        System.out.println("0 - Exit");

        int action;
        int valor;
        boolean active = true;
        while (active) {
            System.out.print("\nSelecione uma acao:");
            action = scanner.nextInt();

            switch (action) {
                case 0:
                    System.out.print("Digite um valor:");
                    valor = scanner.nextInt();
                    fila.insere(valor);
                    break;

                case 1:
                    fila.remover();
                    break;

                case 2:
                    fila.consultar();
                    break;

                case 3:
                    break;

                case 4:
                    break;
            }
        }
    }
}
