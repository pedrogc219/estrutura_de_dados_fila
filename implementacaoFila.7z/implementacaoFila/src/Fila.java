public class Fila {
    private int primeiro;
    private int ultimo;
    private int[] dados;
    private int tamanho;
    public Fila(int tamanho) {
        primeiro = -1;
        ultimo = -1;
        dados = new int[tamanho];
        this.tamanho = tamanho;
    }

    public void insere(int valor) {
        if (cheio()) {
            System.out.println("A fila esta cheia!");
        } else {
            if (vazio()) {
                primeiro = 0;
            }
            if ((ultimo == tamanho-1) && (primeiro != 0)) {
                ultimo = 0;
                dados[ultimo] = valor;
            } else {
                ultimo++;
                dados[ultimo] = valor;
            }
        }
    }

    public void remover() {
        if (vazio()) {
            System.out.println("A fila esta vazia!");
        } else {
            dados[primeiro] = -1;

            if (primeiro == ultimo) { // if it's the last value in the array, resets pointer to default position
                primeiro = -1;
                ultimo = -1;
            } else { // checks if it's necessary to loop back to 0
                if ((primeiro == tamanho - 1) && (ultimo != primeiro)) {
                    primeiro = 0;
                } else {
                    primeiro++;
                }
            }
        }
    }

    public boolean cheio() {
        if (ultimo == primeiro-1) {
            return true;
        } else if ((ultimo == tamanho-1) && primeiro == 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean vazio() {
        if ((ultimo == -1) && (primeiro == -1)) {
            return true;
        } else {
            return false;
        }
    }

    public void consultar() {
        System.out.println("primeiro: "+primeiro);
        System.out.println("ultimo: "+ultimo);
        for (int i = 0; i < tamanho; i++) {
            System.out.print(dados[i]+"\t");
        }
    }
}
